Upload soc-LiveJournal1Adj.txt into input1  and userdata.txt into input2

    Q1:
1. under /Q1 directory
2. input: hadoop jar MutualFriends.jar /input1 /output1
3. output : /output1
4. search specific pairs: hdfs dfs -cat /output1/part-r-00000 | grep "<user1_id_>,<user2_id>\t". For example: hdfs dfs -cat /output1/part-r-00000 | grep "0,1\t"

    Q2:
1. under /Q2 directory
2. input : hadoop jar MaxCommonFriends.jar /output1 /output2
3. output : /output2
4. use the result we got in Q1 in output1

Working on solving others